import langchain
import qdrant_client
import bge_reranker # lub inne biblioteki

class InformationCompetitionRAG:
    def __init__(self, vector_db, embedding_model, reranker_model):
        self.db = vector_db
        self.embedding_model = embedding_model
        self.reranker_model = reranker_model # np. BGE-Reranker-v2-m3

    def search(self, query, metadata_filters, top_k_initial=20, top_k_final=5):
        
        # 1. METADATA FILTERING (Przed filtrowaniem!)
        # Tylko te dokumenty z bazy spełniające warunki (np. typ: 'legal', rok: '2023+')
        filtered_docs = self.db.search(
            query=query, 
            filters=metadata_filters # np. {'field': 'tag', 'value': 'legal'}
        )

        # 2. HYBRID SEARCH (Wektory + Keyword)
        # Wyszukiwanie wektora dla tych filtrów
        initial_candidates = self.db.similarity_search(
            query_vector=self.embedding_model.encode(query),
            k=top_k_initial
        )

        # 3. INFORMATION COMPETITION (RERANKING)
        # To jest "Walka" o uwagę modelu.
        # Wgrywamy kandydatów do Rerankera.
        # Reranker "ocenia" kandydatów na podstawie kontekstu pytania.
        scored_docs = self.reranker_model.rank(initial_candidates)
        
        # 4. FINAL SELECTION
        # Odejmuje "przegranych" (niskie score)
        final_context = scored_docs[:top_k_final]
        
        return final_context
