@echo off
echo.
echo ========================================
echo Uruchamianie serwera API RAGENT (FastAPI)
echo ========================================
echo.
echo Serwer nasluchuje pod adresem: http://localhost:8000
echo.
echo Interfejs Swagger/OpenAPI bedzie dostepny pod: http://localhost:8000/docs
echo.

python -m uvicorn examples.api:app --host 0.0.0.0 --port 8000 --reload

pause
