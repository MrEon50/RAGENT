import sys
import os

# Dodajemy projekt do path dla demówki bez pip install -e .
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sentence_transformers import SentenceTransformer
from ragent import AdvancedRAGPipeline, RagentConfig, Document
from ragent.search import ChromaRetriever

def main():
    print("--- Start RAGENT DEMO ---")
    
    # Inicjalizacja konfiguracji 
    config = RagentConfig(
        bm25_top_k=20,
        vector_top_k=20,
        reranker_top_k=10,
        final_top_k=5, # Ile zostaje na koniec  
        adaptive_threshold_ratio=0.3
    )
    
    # Baza In-memory 
    print("[1] Inicjalizacja ChromaDB Retrievera...")
    vector_db = ChromaRetriever(collection_name="demo_docs")
    
    # Model Wektorów do VectorDB i MMR
    print("[2] Ładowanie modelu Embeddingów (to potrwa z neta jak nie masz)...")
    embedder = SentenceTransformer(config.embedding_model)
    
    print("[3] Montowanie RAGENT Pieline...")
    rag = AdvancedRAGPipeline(
        config=config,
        vector_retriever=vector_db,
        embedding_model=embedder
    )
    
    print("[4] Tworzenie dokumentów walczących ze sobą...\n")
    docs = [
         Document(
             id="doc_1", 
             content="Podatek PIT w 2022 wynosił 17% w pierwszym progu. Istna rewelacja bo było niskie.",
             metadata={"created_at": "2022-01-01", "source_type": "forum", "tag": "podatki"}
         ),
         Document(
             id="doc_2", 
             content="Podatek PIT od roku 2024 to 12% w pierwszej skali. Zmiana ta jest przełomowa dla każdego pracownika.",
             metadata={"created_at": "2024-02-15", "source_type": "official", "tag": "podatki"}
         ),
         Document(
             id="doc_3", 
             content="Zmiany w ustawie o podatku weszły w obrót. Dotyczą głównie PIT u rolników i ulg termicznych.",
             metadata={"created_at": "2024-01-20", "source_type": "verified", "tag": "rolnictwo"}
         ),
         Document(
             id="doc_4", 
             content="Niektórzy twierdzą, że podatek powinien wynosić PIT zawsze tyle zeby nam się żyło dobrze z PIT na pasku u szefa w skali rocznej.",
             metadata={"created_at": "2023-10-10", "source_type": "wiki", "tag": "opinia"}
         ),
         Document(
             id="doc_5", 
             content="Najnowsze regulacje PIT stanowią, że zaliczki na podatek dochodowy muszą uwzględniać ten nowy 12% próg. Skala zmieniła się trwale.",
             metadata={"created_at": "2024-05-30", "source_type": "official", "tag": "podatki"}
         )
    ]
    
    rag.add_documents(docs)
    
    query = "Ile wynosi obecnie podatek PIT w pierwszym progu?"
    print(f"QUERY: '{query}'")
    
    # Filtrujemy tylko oficjalnie brzmiace i podatkowe jesli bysmy chcieli. 
    # Tutaj damy bez filtra żeby RRF wyłapał najpierw
    print("\n--- Rozpoczyna się 'Walka Wymiany (Information Competition)' ---\n")
    result = rag.search(query)
    
    print(" === Wynik Wyszukiwania [Etapy Wyszukiwania] ===")
    print(f"BM25 znalazło kandydatów: {result.pipeline_stats.get('bm25_candidates')}")
    print(f"Wektory znalazły kandydatów: {result.pipeline_stats.get('vector_candidates')}")
    print(f"Zfuzowano kandydatów z RRF: {result.pipeline_stats.get('fusion_candidates')}")
    print(f"Wybrane przez sędziego AI (Reranker Cross-Encoder): {result.pipeline_stats.get('reranked_candidates')}")
    print(f"Wynik ostatecznych kandydatów z Cognitive biases i MMR: {result.pipeline_stats.get('cognitive_candidates')}")
    
    final_context_prompt = rag.get_final_context(result)
    
    print("\n === FINALNY ZBUDOWANY KONTEKST DO MODELU LLM ===")
    print("Ten tekst widzi generator LLM (Zauważ kto wygrał - podatek 2024 z urzędowego tekstu, odrzuceni maruderzy z 2022 odeszli w Cień):")
    print(final_context_prompt)
    
if __name__ == "__main__":
    main()
