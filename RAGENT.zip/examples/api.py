from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import uvicorn

from ragent.core import AdvancedRAGPipeline
from ragent.config import RagentConfig
from ragent.models import Document
from ragent.search import ChromaRetriever
from sentence_transformers import SentenceTransformer

app = FastAPI(title="RAGENT API", description="Information Competition RAG Service")

# Globalne instancje (w produkcji trzymać w lifespan events)
pipeline = None

class DocumentInput(BaseModel):
    id: str
    content: str
    metadata: Optional[Dict[str, Any]] = None

class QueryInput(BaseModel):
    query: str
    metadata_filters: Optional[Dict[str, Any]] = None

@app.on_event("startup")
async def startup_event():
    global pipeline
    print("Inicjalizacja modelu RAGENT (to może chwilę potrwać)...")
    config = RagentConfig()
    vector_db = ChromaRetriever(collection_name="api_docs")
    embedder = SentenceTransformer(config.embedding_model)
    pipeline = AdvancedRAGPipeline(
        config=config, 
        vector_retriever=vector_db, 
        embedding_model=embedder
    )
    print("RAGENT API gotowe!")

@app.post("/add_documents")
async def add_documents(docs: List[DocumentInput]):
    if not pipeline:
        raise HTTPException(status_code=503, detail="Pipeline not initialized yet")
        
    rag_docs = [
        Document(id=d.id, content=d.content, metadata=d.metadata or {}) 
        for d in docs
    ]
    pipeline.add_documents(rag_docs)
    return {"status": "success", "added_count": len(rag_docs)}

@app.post("/search")
async def search(q: QueryInput):
    if not pipeline:
        raise HTTPException(status_code=503, detail="Pipeline not initialized yet")
        
    result = pipeline.search(q.query, metadata_filters=q.metadata_filters)
    final_context = pipeline.get_final_context(result)
    
    # Zwracamy i finalny kontekst dla AI i pocięte fragmenty z metrykami
    return {
        "final_context_prompt": final_context,
        "pipeline_stats": result.pipeline_stats,
        "selected_documents": [
            {
                "id": sd.document.id, 
                "score": sd.score, 
                "stage": sd.scoring_stage
            } for sd in result.documents
        ]
    }

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)
