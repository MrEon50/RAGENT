@echo off
echo.
echo ========================================
echo Uruchamianie demonstracji RAGENT...
echo ========================================
echo.
echo Pierwsze uruchomienie pobierze modele AI (ok. 2GB) jesli jeszcze ich nie ma.
echo Moze to chwile potrwac.
echo.

python examples\demo.py

echo.
echo.
pause
