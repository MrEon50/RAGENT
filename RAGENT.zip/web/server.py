"""
RAGENT Web Server – serwer FastAPI obsługujący:
1. Stronę główną (chat UI)
2. Endpointy API  (/api/models, /api/chat, /api/documents, /api/search)
3. Integrację z Ollama (lokalne modele LLM + embeddings)
4. Pipeline RAGENT (Information Competition)
"""
import os
import sys
import json
import asyncio
import httpx
import psutil
import time
import uuid
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup
from ddgs import DDGS
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# Dodaj root projektu do path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ragent.core import AdvancedRAGPipeline
from ragent.config import RagentConfig
from ragent.models import Document
from ragent.search.vector import ChromaRetriever

# ─── Konfiguracja Ollama ────────────────────────────────────────
OLLAMA_BASE = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")

app = FastAPI(title="RAGENT Web")

# ─── Globalny stan ──────────────────────────────────────────────
pipeline: Optional[AdvancedRAGPipeline] = None
ollama_embed_model: str = "mxbai-embed-large:latest"
ragent_enabled: bool = False
internet_enabled: bool = False
conversation_history: List[Dict[str, str]] = []
document_store: List[Dict[str, Any]] = []
bookmarks_store: List[Dict[str, Any]] = []

# Nowe globals dla bookmarków z frontem
global_notifications: List[str] = []
active_bookmarks: Dict[str, Any] = {}
current_chat_model: str = "llama3"

# Monitoring systemu (CPU/RAM/NET)
last_net_io = None
last_net_time = 0

# Folder na zapisane bazy
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)
BOOKMARKS_FILE = DATA_DIR / "bookmarks.json"

def load_bookmarks():
    global bookmarks_store
    if BOOKMARKS_FILE.exists():
        try:
            with open(BOOKMARKS_FILE, "r", encoding="utf-8") as f:
                bookmarks_store = json.load(f)
        except Exception as e:
            print(f"Błąd ładowania zakładek: {e}")

def save_bookmarks():
    try:
        with open(BOOKMARKS_FILE, "w", encoding="utf-8") as f:
            json.dump(bookmarks_store, f, indent=4)
    except Exception as e:
        print(f"Błąd zapisu zakładek: {e}")


# ─── Adapter embeddingów Ollama ─────────────────────────────────
class OllamaEmbedder:
    """Adapter klasy embedding, który woła Ollama /api/embed zamiast sentence-transformers."""

    def __init__(self, model: str = "mxbai-embed-large:latest"):
        self.model = model

    def encode(self, texts, **kwargs):
        """Kompatybilny interfejs z sentence-transformers .encode()"""
        import numpy as np
        if isinstance(texts, str):
            texts = [texts]
            
        embeddings = []
        for text in texts:
            try:
                import requests
                resp = requests.post(
                    f"{OLLAMA_BASE}/api/embed",
                    json={"model": self.model, "input": text},
                    timeout=30
                )
                resp.raise_for_status()
                data = resp.json()
                # Ollama /api/embed zwraca {"embeddings": [[...]]}
                emb = data.get("embeddings", [[]])[0]
                embeddings.append(emb)
            except Exception as e:
                print(f"[OllamaEmbedder] Błąd embeddingu: {e}")
                # Fallback: zero-vector (384 dim as safe default)
                embeddings.append([0.0] * 1024)
                
        return np.array(embeddings)


def init_ragent_pipeline():
    """Tworzy / resetuje pipeline RAGENT z Ollama embedder."""
    global pipeline
    config = RagentConfig(
        bm25_top_k=20,
        vector_top_k=20,
        reranker_top_k=10,
        final_top_k=5,
        adaptive_threshold_ratio=0.3,
        embedding_model=ollama_embed_model,
    )
    vector_db = ChromaRetriever(collection_name="ragent_web")
    embedder = OllamaEmbedder(model=ollama_embed_model)
    pipeline = AdvancedRAGPipeline(
        config=config,
        vector_retriever=vector_db,
        embedding_model=embedder,
    )
    # Re-index stored docs if any
    if document_store:
        docs = [
            Document(id=d["id"], content=d["content"], metadata=d.get("metadata", {}))
            for d in document_store
        ]
        pipeline.add_documents(docs)
    print(f"[RAGENT] Pipeline zainicializowany z modelem embeddingów: {ollama_embed_model}")


# ─── Pydantic modele ────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    model: str = "llama3"
    ragent_enabled: bool = False

class DocumentInput(BaseModel):
    id: str
    content: str
    metadata: Optional[Dict[str, Any]] = None

class ToggleRagent(BaseModel):
    enabled: bool
    embed_model: str = "mxbai-embed-large:latest"

class ToggleInternet(BaseModel):
    enabled: bool

class BookmarkInput(BaseModel):
    name: str
    schedule_time: str
    source_type: str
    path: str
    prompt: str
    is_recurring: bool = True
    max_links: int = 1


# ─── Endpointy API ──────────────────────────────────────────────

@app.get("/api/models")
async def list_models():
    """Pobiera listę modeli z Ollama."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{OLLAMA_BASE}/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = [m["name"] for m in data.get("models", [])]
            return {"models": models, "ollama_online": True}
    except Exception as e:
        return {"models": [], "ollama_online": False, "error": str(e)}

@app.get("/api/system_stats")
async def system_stats(model: str = "llama3"):
    """Zwraca zużycie CPU, RAM i transfer sieci z wykorzystaniem psutil."""
    global last_net_io, last_net_time, current_chat_model
    
    if model and model != "None" and model != "":
        current_chat_model = model
    
    cpu = psutil.cpu_percent(interval=None)
    ram = psutil.virtual_memory().percent
    
    net_io = psutil.net_io_counters()
    now = time.time()
    
    upload_speed = 0.0
    download_speed = 0.0
    
    if last_net_io is not None and last_net_time > 0:
        dt = now - last_net_time
        if dt > 0:
            upload_speed = (net_io.bytes_sent - last_net_io.bytes_sent) / dt
            download_speed = (net_io.bytes_recv - last_net_io.bytes_recv) / dt
            
    last_net_io = net_io
    last_net_time = now
    
    # Wysłanie powiadomień
    global global_notifications, active_bookmarks
    notifs = global_notifications.copy()
    global_notifications.clear()
    
    return {
        "cpu_percent": cpu,
        "ram_percent": ram,
        "upload_bps": upload_speed,
        "download_bps": download_speed,
        "notifications": notifs,
        "active_bookmarks": [{"id": k, "name": v["name"]} for k, v in active_bookmarks.items()]
    }

@app.post("/api/ragent/toggle")
async def toggle_ragent(body: ToggleRagent):
    global ragent_enabled, ollama_embed_model, pipeline
    ragent_enabled = body.enabled
    ollama_embed_model = body.embed_model
    if ragent_enabled and pipeline is None:
        init_ragent_pipeline()
    return {"ragent_enabled": ragent_enabled, "embed_model": ollama_embed_model}


@app.post("/api/internet/toggle")
async def toggle_internet(body: ToggleInternet):
    global internet_enabled
    internet_enabled = body.enabled
    return {"internet_enabled": internet_enabled}


@app.get("/api/bookmarks")
async def get_bookmarks():
    return {"bookmarks": bookmarks_store}


@app.post("/api/bookmarks")
async def add_bookmark(bm: BookmarkInput):
    new_bm = {
        "id": str(uuid.uuid4()),
        "name": bm.name,
        "schedule_time": bm.schedule_time,
        "source_type": bm.source_type,
        "path": bm.path,
        "prompt": bm.prompt,
        "is_recurring": bm.is_recurring,
        "max_links": bm.max_links,
        "enabled": True,
        "last_run": None
    }
    bookmarks_store.append(new_bm)
    save_bookmarks()
    return {"status": "ok", "bookmark": new_bm}


@app.delete("/api/bookmarks/{bm_id}")
async def delete_bookmark(bm_id: str):
    global bookmarks_store
    bookmarks_store = [b for b in bookmarks_store if b["id"] != bm_id]
    save_bookmarks()
    return {"status": "ok"}


@app.post("/api/bookmarks/{bm_id}/stop")
async def stop_bookmark(bm_id: str):
    if bm_id in active_bookmarks:
        task = active_bookmarks[bm_id].get("task")
        if task:
            task.cancel()
        return {"status": "ok", "message": "Zatrzymano zadanie."}
    return {"status": "not_found"}

@app.post("/api/documents")
async def add_documents(docs: List[DocumentInput]):
    global pipeline
    if not ragent_enabled:
        raise HTTPException(400, "RAGENT nie jest włączony. Włącz przełącznik RAGENT.")
    if pipeline is None:
        init_ragent_pipeline()

    rag_docs = []
    for d in docs:
        meta = d.metadata or {}
        if "created_at" not in meta:
            meta["created_at"] = datetime.now().isoformat()
        if "source_type" not in meta:
            meta["source_type"] = "default"
        doc = Document(id=d.id, content=d.content, metadata=meta)
        rag_docs.append(doc)
        document_store.append({"id": d.id, "content": d.content, "metadata": meta})

    pipeline.add_documents(rag_docs)
    return {"added": len(rag_docs), "total": len(document_store)}


@app.get("/api/documents")
async def get_documents():
    return {"documents": document_store, "count": len(document_store)}


@app.post("/api/chat")
async def chat(req: ChatRequest):
    """Główny endpoint czatu z opcjonalnym RAGENT context injection."""
    global conversation_history, current_chat_model

    user_msg = req.message.strip()
    model = req.model
    current_chat_model = model
    use_ragent = req.ragent_enabled and ragent_enabled and pipeline is not None

    # ─── Kontekst RAGENT ────────────────────────────────
    ragent_context = ""
    ragent_stats = {}
    if use_ragent and document_store:
        try:
            result = pipeline.search(user_msg)
            ragent_context = pipeline.get_final_context(result)
            ragent_stats = result.pipeline_stats
        except Exception as e:
            ragent_context = ""
            ragent_stats = {"error": str(e)}

    # ─── System prompt z kontekstem RAGENT ───────────────
    system_prompt = "Jesteś pomocnym asystentem AI."
    if ragent_context:
        system_prompt += (
            "\n\nPoniżej znajduje się kontekst pobrany przez system RAGENT "
            "(Information Competition Pipeline). Użyj tych informacji do odpowiedzi, "
            "ale nie wspominaj o systemie RAGENT w odpowiedzi.\n\n"
            f"--- RAGENT CONTEXT ---\n{ragent_context}\n--- END CONTEXT ---"
        )

    # ─── Buduj historię konwersacji ──────────────────────
    messages = [{"role": "system", "content": system_prompt}]
    # Dodaj ostatnie 10 wiadomości historii
    for msg in conversation_history[-10:]:
        messages.append(msg)
    messages.append({"role": "user", "content": user_msg})

    # ─── Wołaj Ollama ────────────────────────────────────
    token_stats = {}
    thinking_text = ""
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{OLLAMA_BASE}/api/chat",
                json={"model": model, "messages": messages, "stream": False},
            )
            resp.raise_for_status()
            data = resp.json()
            assistant_msg = data.get("message", {}).get("content", "Brak odpowiedzi.")

            # Ekstrakcja danych tokenów
            prompt_tokens = data.get("prompt_eval_count", 0)
            completion_tokens = data.get("eval_count", 0)
            token_stats = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens
            }

            # Parsowanie modelu myślacego (np. DeepSeek) z `<think>...</think>`
            import re
            match = re.search(r"<think>(.*?)</think>", assistant_msg, re.DOTALL | re.IGNORECASE)
            if match:
                thinking_text = match.group(1).strip()
                assistant_msg = re.sub(r"<think>.*?</think>", "", assistant_msg, flags=re.DOTALL | re.IGNORECASE).strip()

    except Exception as e:
        assistant_msg = f"Błąd połączenia z Ollama: {e}"

    # ─── Zapisz historię ─────────────────────────────────
    conversation_history.append({"role": "user", "content": user_msg})
    conversation_history.append({"role": "assistant", "content": assistant_msg})

    return {
        "response": assistant_msg,
        "thinking": thinking_text,
        "token_stats": token_stats,
        "ragent_used": use_ragent and bool(ragent_context),
        "ragent_stats": ragent_stats,
    }


@app.post("/api/history/clear")
async def clear_history():
    global conversation_history
    conversation_history = []
    return {"status": "ok"}


class SaveRequest(BaseModel):
    filename: str


@app.post("/api/save")
async def save_database(req: SaveRequest):
    """Zapisuje document_store do pliku JSON w folderze data/."""
    if not document_store:
        raise HTTPException(400, "Baza jest pusta – nie ma czego zapisać.")

    # Sanityzacja nazwy pliku – tylko litery, cyfry, myślniki, podkreślenia
    safe_name = "".join(c for c in req.filename if c.isalnum() or c in ('-', '_')).strip()
    if not safe_name:
        raise HTTPException(400, "Nieprawidłowa nazwa pliku.")
    if not safe_name.endswith(".json"):
        safe_name += ".json"

    save_path = DATA_DIR / safe_name
    payload = {
        "saved_at": datetime.now().isoformat(),
        "embed_model": ollama_embed_model,
        "document_count": len(document_store),
        "documents": document_store,
    }
    save_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"status": "saved", "file": safe_name, "count": len(document_store)}


@app.post("/api/load")
async def load_database(req: SaveRequest):
    """Wczytuje document_store z pliku JSON i re-indeksuje w pipeline."""
    global document_store, pipeline

    safe_name = req.filename if req.filename.endswith(".json") else req.filename + ".json"
    load_path = DATA_DIR / safe_name

    if not load_path.exists():
        # Szukamy pliku case-insensitive
        matches = list(DATA_DIR.glob("*.json"))
        found = next((p for p in matches if p.name.lower() == safe_name.lower()), None)
        if not found:
            available = [p.name for p in matches]
            raise HTTPException(404, f"Plik '{safe_name}' nie istnieje. Dostępne: {available}")
        load_path = found

    payload = json.loads(load_path.read_text(encoding="utf-8"))
    loaded_docs = payload.get("documents", [])

    if not loaded_docs:
        raise HTTPException(400, "Plik jest pusty lub uszkodzony.")

    # Zastąp bieżącą bazę
    document_store.clear()
    document_store.extend(loaded_docs)

    # Re-inicjalizuj pipeline i zaindeksuj wczytane dokumenty
    if ragent_enabled:
        init_ragent_pipeline()  # to wewnętrznie re-indeksuje document_store
    else:
        # Nawet jeśli RAGENT wyłączony, zapisz do store – zaindeksuje się przy włączeniu
        pass

    return {
        "status": "loaded",
        "file": load_path.name,
        "count": len(document_store),
        "saved_at": payload.get("saved_at", "nieznana"),
        "embed_model": payload.get("embed_model", "nieznany"),
    }


@app.get("/api/saves")
async def list_saves():
    """Zwraca listę zapisanych baz."""
    files = sorted(DATA_DIR.glob("*.json"))
    result = []
    for f in files:
        try:
            meta = json.loads(f.read_text(encoding="utf-8"))
            result.append({
                "filename": f.name,
                "saved_at": meta.get("saved_at", ""),
                "count": meta.get("document_count", 0),
            })
        except Exception:
            result.append({"filename": f.name, "saved_at": "", "count": 0})
    return {"saves": result}


@app.get("/", response_class=HTMLResponse)
async def serve_index():
    index_path = Path(__file__).parent / "index.html"
    return HTMLResponse(index_path.read_text(encoding="utf-8"))


class ContextFileRequest(BaseModel):
    filepath: str
    chunk_size: int = 1000
    chunk_overlap: int = 100
    source_type: str = "file"


@app.post("/api/context")
async def add_context_file(req: ContextFileRequest):
    """Wczytuje plik z dysku, dzieli na fragmenty i indeksuje w RAGENT."""
    global pipeline

    file_path = Path(req.filepath)
    if not file_path.exists():
        raise HTTPException(404, f"Plik nie istnieje: {req.filepath}")
    if not file_path.is_file():
        raise HTTPException(400, "Podana sciezka nie jest plikiem.")
    if file_path.suffix.lower() not in (".txt", ".md", ".csv", ".log", ".py", ".json", ".html"):
        raise HTTPException(400, f"Nieobslugiwany typ: {file_path.suffix}. OK: txt, md, csv, log, py, json, html")

    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        raise HTTPException(500, f"Blad odczytu: {e}")

    if not content.strip():
        raise HTTPException(400, "Plik jest pusty.")

    # Podziel na fragmenty z zakladka
    chunks = []
    start = 0
    while start < len(content):
        chunk = content[start: start + req.chunk_size].strip()
        if chunk:
            chunks.append(chunk)
        start += req.chunk_size - req.chunk_overlap

    if not chunks:
        raise HTTPException(400, "Nie udalo sie podzielic pliku.")

    if not ragent_enabled:
        raise HTTPException(400, "Wlacz RAGENT (/ragent on) przed dodaniem pliku.")
    if pipeline is None:
        init_ragent_pipeline()

    file_stem = file_path.stem
    now_iso = datetime.now().isoformat()
    rag_docs = []
    for i, chunk_text in enumerate(chunks):
        doc_id = f"{file_stem}_c{i+1}_{int(datetime.now().timestamp())}"
        meta = {
            "source_type": req.source_type,
            "source_file": str(file_path),
            "filename": file_path.name,
            "chunk_index": i + 1,
            "chunk_total": len(chunks),
            "created_at": now_iso,
        }
        doc = Document(id=doc_id, content=chunk_text, metadata=meta)
        rag_docs.append(doc)
        document_store.append({"id": doc_id, "content": chunk_text, "metadata": meta})

    pipeline.add_documents(rag_docs)
    return {
        "status": "indexed",
        "filename": file_path.name,
        "chunks": len(chunks),
        "total_documents": len(document_store),
    }


# ─── Worker dla zakladek (Scheduler) ──────────────────────────
async def process_bookmark(bm):
    global active_bookmarks
    bm_id = bm['id']
    bm_name = bm['name']
    
    print(f"[RAGENT Worker] Uruchamiam zakładkę: {bm_name}")
    raw_text = ""
    try:
        # Pobieranie tresci
        if bm["source_type"] == "internet" and internet_enabled:
            # DuckDuckGo wyszukiwanie i pobieranie zawartosci
            limit = int(bm.get("max_links", 1))
            with DDGS() as ddgs:
                results = ddgs.text(bm["path"], max_results=limit)
                
                parts = []
                if results:
                    async with httpx.AsyncClient() as client:
                        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
                        for r in results:
                            link = r.get("href", "")
                            title = r.get("title", "")
                            snippet = r.get("body", "")
                            
                            page_content = ""
                            if link:
                                try:
                                    res = await client.get(link, timeout=10, headers=headers)
                                    soup = BeautifulSoup(res.content, "html.parser")
                                    page_content = soup.get_text(separator=' ', strip=True)[:4000] # Limit per page
                                    lp = page_content.lower()
                                    if "enable javascript" in lp or "captcha" in lp or "checking if the site connection is secure" in lp or "please wait while we verify" in lp:
                                        page_content = "[Dostęp do pełnego artykułu odrzucony (Wymagany włączony JS/Zabezpieczenie typu Cloudflare). Oprzyj raport WYŁĄCZNIE NA OPISIE z wyszukiwarki POWYŻEJ !!]"
                                except Exception as e:
                                    page_content = f"Nie udało się wejść na stronę: {e}"
                                    
                            parts.append(f"Tytuł: {title}\nOpis: {snippet}\nZaczytana Treść ze strony ({link}):\n{page_content}")
                            
                raw_text = "\n\n---\n\n".join(parts)[:15000]
                
        elif bm["source_type"] == "url" and internet_enabled:
            async with httpx.AsyncClient() as client:
                res = await client.get(bm["path"], timeout=15)
                soup = BeautifulSoup(res.content, "html.parser")
                raw_text = soup.get_text(separator=' ', strip=True)[:15000]
        elif bm["source_type"] == "local":
            fp = Path(bm["path"])
            if fp.exists() and fp.is_file():
                raw_text = fp.read_text(encoding="utf-8", errors="replace")[:15000]

        if not raw_text.strip():
            print(f"[RAGENT Worker] Brak danych dla: {bm['name']} (Internet OFF?)")
            return

        # Uruchom u Ollamy
        instruction = f"Przeanalizuj podane dane i zrealizuj zadanie.\n\n[ZADANIE]: {bm['prompt']}\n\n[DANE]:\n{raw_text}"
        messages = [{"role": "user", "content": instruction}]
        
        async with httpx.AsyncClient(timeout=600) as client:
            resp = await client.post(
                f"{OLLAMA_BASE}/api/chat",
                json={"model": current_chat_model, "messages": messages, "stream": False}, # mozna zrzucić na default lub konfigurować
            )
            data = resp.json()
            ans = data.get("message", {}).get("content", "")
            
            if ans:
                global global_notifications
                notif_msg = f"⏱️ **Zakładka [ {bm['name']} ] wykonała się!**\nOto rezultat:\n\n{ans}"
                global_notifications.append(notif_msg)
                
                # Dodaj do glownego czatu zeby zapisac to w historii
                conversation_history.append({"role": "system", "content": f"Zakładka {bm['name']} zaktualizowana."})
                conversation_history.append({"role": "assistant", "content": notif_msg})
                
                if ragent_enabled and pipeline is not None:
                    doc_id = f"bookmark_{bm['id']}_{int(time.time())}"
                    meta = {
                        "source_type": "bookmark",
                        "bookmark_name": bm["name"],
                        "created_at": datetime.now().isoformat()
                    }
                    new_doc = Document(id=doc_id, content=f"Odpowiedź z zakładki [{bm['name']}]: {ans}", metadata=meta)
                    pipeline.add_documents([new_doc])
                    document_store.append({"id": doc_id, "content": f"Odpowiedź z zakładki [{bm['name']}]: {ans}", "metadata": meta})
                    print(f"[RAGENT Worker] ✅ Zakładka wprowadzona do bazy.")
            
    except asyncio.CancelledError:
         print(f"[RAGENT Worker] Anulowano zakładkę: {bm_name}")
         global_notifications.append(f"🛑 **Oto potwierdzenie:** Zatrzymano w tle zakładkę [ {bm_name} ] przed ukończeniem zadania.")
    except Exception as e:
         print(f"[RAGENT Worker] Błąd zakładki {bm_name}: {e}")
    finally:
         active_bookmarks.pop(bm_id, None)

    bm["last_run"] = datetime.now().strftime("%H:%M")
    save_bookmarks()

async def scheduler_loop():
    while True:
        now = datetime.now()
        current_time_str = now.strftime("%H:%M")
        
        for bm in bookmarks_store:
            # Sprawdź czy czas się zgadza
            if bm.get("enabled", True) and bm["schedule_time"] == current_time_str:
                # Ogranicz by nie puścić pare razy w ciągu tej samej minuty
                if bm.get("last_run") != current_time_str:
                    task = asyncio.create_task(process_bookmark(bm))
                    active_bookmarks[bm["id"]] = {"name": bm["name"], "task": task}
                    
                    if not bm.get("is_recurring", True):
                        bm["enabled"] = False
        
        await asyncio.sleep(30)

@app.on_event("startup")
async def on_startup():
    load_bookmarks()
    asyncio.create_task(scheduler_loop())


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="127.0.0.1", port=8765)
