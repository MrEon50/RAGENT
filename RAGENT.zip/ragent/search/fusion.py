from typing import List, Dict

from ragent.models import ScoredDocument

def reciprocal_rank_fusion(ranked_lists: List[List[ScoredDocument]], k: int = 60) -> List[ScoredDocument]:
    """
    RRF algorytm mergujący wiele list dokumentów oparty tylko o ich ranking, a nie score.
    To rozwiązuje problem nierównych skal wyników z rożnych kanałów (np Vector a BM25).
    Metoda zakłada, że ScoredDocumenty w `ranked_lists` są już we właściwej kolejności posortowane wg. swoich kanałów.
    """
    rrf_score: Dict[str, float] = {}
    doc_map: Dict[str, ScoredDocument] = {}

    for ranked_list in ranked_lists:
        for original_rank, scored_doc in enumerate(ranked_list):
            doc_id = scored_doc.document.id
            
            # Zapamiętaj sam dokument zeby było jak go potem zwrócić
            if doc_id not in doc_map:
                # Kopia, żeby nie nadpisywać stage/score starych
                doc_map[doc_id] = scored_doc
                rrf_score[doc_id] = 0.0
                
            # Główny równanie RRF 1 / (rank + k)
            # rank robimy 1-indexed
            rrf_score[doc_id] += 1.0 / ((original_rank + 1) + k)

    # Przygotuj listę połączoną, wylicz max by znormalizować RRF
    res = []
    max_score = max(rrf_score.values()) if rrf_score else 1.0
    
    for doc_id, final_score in rrf_score.items():
        normalized = final_score / max_score if max_score > 0 else 0.0
        new_sd = ScoredDocument(
            document=doc_map[doc_id].document,
            score=normalized,
            scoring_stage="rrf_fusion"
        )
        res.append(new_sd)
        
    res.sort(key=lambda x: x.score, reverse=True)
    return res
