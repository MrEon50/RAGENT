from rank_bm25 import BM25Okapi
from typing import List, Dict
import string

from ragent.models import Document, ScoredDocument

class BM25Retriever:
    """Prosty wrapper dla rank_bm25"""
    def __init__(self):
        self.bm25_model = None
        self.documents: List[Document] = []
        
    def _tokenize(self, text: str) -> List[str]:
        # Prosta tokenizacja z wyrzucaniem interpunkcji
        text = text.lower()
        for punct in string.punctuation:
            text = text.replace(punct, " ")
        return text.split()
        
    def index(self, documents: List[Document]):
        """Indeksuje dokumenty."""
        if not documents:
            return
            
        self.documents = documents
        tokenized_corpus = [self._tokenize(doc.content) for doc in documents]
        self.bm25_model = BM25Okapi(tokenized_corpus)
        
    def search(self, query: str, top_k: int = 20) -> List[ScoredDocument]:
        """Szuka dokumentów używając okapi."""
        if not self.bm25_model or not self.documents:
            return []
            
        tokenized_query = self._tokenize(query)
        scores = self.bm25_model.get_scores(tokenized_query)
        
        # Tworzy listę wynikową
        results = []
        for i, doc in enumerate(self.documents):
            score = scores[i]
            if score > 0:
                results.append((score, doc))
                
        # Sortuj po wynikach BM25
        results.sort(key=lambda x: x[0], reverse=True)
        
        # Pobierz najwyższy score żeby normalizować 0-1 (prosta normalizacja)
        max_score = results[0][0] if results else 1.0
        
        final_results = []
        for score, doc in results[:top_k]:
            normalized_score = score / max_score if max_score > 0 else 0.0
            final_results.append(ScoredDocument(
                document=doc,
                score=normalized_score,
                scoring_stage="bm25"
            ))
            
        return final_results
