from abc import ABC, abstractmethod
from typing import List, Dict, Any

from ragent.models import Document, ScoredDocument

class BaseVectorRetriever(ABC):
    @abstractmethod
    def index(self, documents: List[Document], embeddings: List[List[float]]):
        pass

    @abstractmethod
    def search(self, query_embedding: List[float], top_k: int, filters: Dict[str, Any] = None) -> List[ScoredDocument]:
        pass

class ChromaRetriever(BaseVectorRetriever):
    """Implementacja wektorowej pętli opartej o in-memory chromadb. """
    def __init__(self, collection_name: str = "ragent_collection"):
        try:
            import chromadb
            self.client = chromadb.Client()
            # Nadpisz by mieć świeże przy testach
            try:
                self.client.delete_collection(name=collection_name)
            except:
                pass
            self.collection = self.client.create_collection(
                name=collection_name,
                metadata={"hnsw:space": "cosine"}
            )
        except ImportError:
            raise ImportError("Proszę upewnij się że chromadb jest zainstalowany.")
            
        self.doc_store: Dict[str, Document] = {}

    def index(self, documents: List[Document], embeddings: List[List[float]]):
        if not documents:
            return
            
        ids = [doc.id for doc in documents]
        texts = [doc.content for doc in documents]
        metadatas = [doc.metadata for doc in documents]
        
        # Odrębny zapis do pamiętania pełnych struktur z id
        for doc in documents:
            self.doc_store[doc.id] = doc

        self.collection.add(
            ids=ids,
            embeddings=embeddings,
            metadatas=metadatas,
            documents=texts
        )

    def search(self, query_embedding: List[float], top_k: int, filters: Dict[str, Any] = None) -> List[ScoredDocument]:
        if not self.doc_store:
            return []
            
        kwargs = {
            "query_embeddings": [query_embedding],
            "n_results": top_k
        }
        
        # Translate simple dictionary filters to Chroma format
        if filters:
            chroma_filters = {}
            if len(filters) == 1:
                k, v = list(filters.items())[0]
                chroma_filters = {k: v} # exact match
            else:
                chroma_filters = {"$and": [{k: v} for k, v in filters.items()]}
            kwargs["where"] = chroma_filters

        results = self.collection.query(**kwargs)
        
        sc_docs = []
        if results and results["ids"] and len(results["ids"][0]) > 0:
            ids = results["ids"][0]
            distances = results["distances"][0]
            
            # W chroma (cosine) distance to 1 - cosine_similarity (0 = najblodszy pod kątem metryki "cosine dist" tamteż)
            # Im mniejszy dist tym lepszy wektor (dist 0 = sim 1.0)
            for i, doc_id in enumerate(ids):
                # Normalizacja na sim zeby wyzszy score byl lepszy
                sim = 1.0 - distances[i] 
                doc = self.doc_store.get(doc_id)
                if doc:
                    sc_docs.append(ScoredDocument(
                        document=doc,
                        score=max(0.0, sim), # zeby bylo 0-1
                        scoring_stage="vector_search"
                    ))
        
        return sc_docs
