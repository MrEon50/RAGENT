from typing import List
import numpy as np

from ragent.models import ScoredDocument

class CrossEncoderReranker:
    """Implementacja re-rankera opartego o cross encoder z bge"""
    def __init__(self, model_name: str = "BAAI/bge-reranker-v2-m3"):
        self.model_name = model_name
        self.model = None

    def _load_model(self):
        if self.model is None:
            from sentence_transformers import CrossEncoder
            self.model = CrossEncoder(self.model_name, device="cpu")

    def rerank(self, query: str, documents: List[ScoredDocument], top_k: int) -> List[ScoredDocument]:
        """Przesuwa kandydatów w nowy order oparty o relację Cross Encoder z zapytaniem."""
        if not documents:
            return []

        self._load_model()
        
        # Create pairs: (query, doc_text)
        pairs = [(query, sd.document.content) for sd in documents]
        
        # Cross encoder returns raw logits, need to normalize/sigmoid mostly, but values range is fine for sorting.
        # For bge-reranker, higher is better. Use sigmoid for 0-1 scale.
        logits = self.model.predict(pairs)
        
        def sigmoid(x):
            return 1 / (1 + np.exp(-x))
            
        scores = sigmoid(logits) if isinstance(logits, np.ndarray) else [sigmoid(l) for l in logits]

        reranked = []
        for i, sd in enumerate(documents):
            # tworzymy nową klasę score 
            reranked.append(ScoredDocument(
                document=sd.document,
                score=float(scores[i]),
                scoring_stage="cross_encoder"
            ))

        # Sortuj 
        reranked.sort(key=lambda x: x.score, reverse=True)
        return reranked[:top_k]
