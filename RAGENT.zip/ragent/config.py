from pydantic import BaseModel, Field
from typing import Dict, Optional

class RagentConfig(BaseModel):
    # Parametry Search
    bm25_top_k: int = Field(default=20, description="Ilu kandydatów pobierać z BM25")
    vector_top_k: int = Field(default=20, description="Ilu kandydatów pobierać z bazy wektorowej")
    rrf_k: int = Field(default=60, description="Parametr K dla Reciprocal Rank Fusion")

    # Parametry Rerankera
    reranker_model: str = Field(default="BAAI/bge-reranker-v2-m3", description="Model cross-encoder na HuggingFace")
    reranker_top_k: int = Field(default=10, description="Ile dokumentów zostawić po cross-encoerze")

    # Cognitive Layer (Czas, Źródła, MMR)
    time_decay_lambda: float = Field(default=0.001, description="Decay dla freshness. Większy parametr = szybszy spadek score(czasu)")
    source_authority_weights: Dict[str, float] = Field(
        default_factory=lambda: {"official": 1.5, "verified": 1.2, "wiki": 1.1, "default": 1.0, "forum": 0.8},
        description="Mnożnik wiarygodności per typ źródła"
    )
    mmr_lambda: float = Field(default=0.7, description="1.0 to tylko relevance, 0.0 to tylko diversity")
    mmr_similarity_threshold: float = Field(default=0.85, description="Powyżej tego progu cosine similarity tnie punkty")

    # Finalne ograniczenia (Threshold, Budżet)
    final_top_k: int = Field(default=5, description="Docelowa liczba fragmentów idących do LLMa")
    adaptive_threshold_ratio: float = Field(default=0.3, description="Odrzucamy dokumenty mające score < (30%) najwyższego score'a")
    max_context_tokens: int = Field(default=3000, description="Całkowity budżet tokenów dla finalnego wyjścia")

    # Wektoryzacja (Tylko w razie gdy core zajmuje się embeddingiem query)
    embedding_model: str = Field(default="sentence-transformers/all-MiniLM-L6-v2", description="Model do zamiany zapytań na wektory")
