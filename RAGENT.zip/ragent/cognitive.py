from typing import List, Dict, Callable
import datetime
import math
import numpy as np

from ragent.models import ScoredDocument
from ragent.config import RagentConfig

class CognitiveLayer:
    """
    CognitiveLayer modyfikuje score przyznane przez reranker biorąc poprawkę na:
    1. time decay (wiek)
    2. authority (źródło)
    3. diversyfykacja informacyjna (MMR)
    """
    def __init__(self, config: RagentConfig, embedding_model=None):
        self.config = config
        self.embedding_model = embedding_model

    def _compute_freshness(self, doc_date_str: str) -> float:
        """Kalkulator decay dla freshness. 0 dni = 1.0, nieskonczonosc dni = 0.0"""
        if not doc_date_str:
            return 1.0
            
        try:
            doc_date = datetime.datetime.fromisoformat(doc_date_str)
            now = datetime.datetime.now(doc_date.tzinfo)
            delta = now - doc_date
            days_old = max(0, delta.days)
            # exponential decay
            return math.exp(-self.config.time_decay_lambda * days_old)
        except Exception:
            return 1.0

    def _cosine_similarity(self, a_vec, b_vec) -> float:
        dot = np.dot(a_vec, b_vec)
        norm_a = np.linalg.norm(a_vec)
        norm_b = np.linalg.norm(b_vec)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    def apply_cognitive_biases(self, query: str, documents: List[ScoredDocument]) -> List[ScoredDocument]:
        """Aplikuje czas oraz aurorytet. Potem aplikuje MMR jeśli model wektorow przekazany."""
        
        # Etap 1: Czas + Authority
        biased = []
        for sd in documents:
            metadata = sd.document.metadata
            doc_date = metadata.get("created_at")
            source = metadata.get("source_type", "default")
            
            freshness_Multiplier = self._compute_freshness(doc_date)
            authority_Multiplier = self.config.source_authority_weights.get(
                source, self.config.source_authority_weights.get("default", 1.0)
            )
            
            new_score = sd.score * freshness_Multiplier * authority_Multiplier
            
            biased.append(ScoredDocument(
                document=sd.document,
                score=new_score,
                scoring_stage="cognitive_bias"
            ))

        # Posortować po tych Biasach
        biased.sort(key=lambda x: x.score, reverse=True)

        # Etap 2: Wymuszenie Diversity (MMR - Maximal Marginal Relevance)
        if not self.embedding_model or not biased:
            return biased
            
        # Potrzebujemy wektorów by znać podobieństwo pomiędzy SAMYMI dokumentami 
        texts = [sd.document.content for sd in biased]
        doc_embeddings = self.embedding_model.encode(texts)
        
        # Zgodnie z MMR:
        # Puste by budować wyselekcjonowane dokumenty (rozłączne / diversity)
        selected_indices = []
        unselected_indices = list(range(len(biased)))
        
        final_mmr_list = []
        lamb = self.config.mmr_lambda
        
        # max_score uzywany dla iteratywnosci. Inicjalnie bierzemy tego co mial największy bias score.
        while unselected_indices and len(selected_indices) < len(biased):
            best_idx = -1
            best_mmr_score = float('-inf')
            
            for check_idx in unselected_indices:
                relevance = biased[check_idx].score # to jest od cross encodera * biasy
                
                max_similarity_to_selected = 0.0
                for s_idx in selected_indices:
                    sim = self._cosine_similarity(doc_embeddings[check_idx], doc_embeddings[s_idx])
                    if sim > max_similarity_to_selected:
                        max_similarity_to_selected = sim

                mmr_score = lamb * relevance - (1 - lamb) * max_similarity_to_selected
                
                if mmr_score > best_mmr_score:
                    best_mmr_score = mmr_score
                    best_idx = check_idx
                    
            if best_idx != -1:
                selected_indices.append(best_idx)
                unselected_indices.remove(best_idx)
                # Obetnij po twardym sim jesli trzeba (dla ekstremów) - opcjonalnie
                # tu tylko re-ordujemy.
                final_mmr_list.append(ScoredDocument(
                     document=biased[best_idx].document,
                     score=best_mmr_score,
                     scoring_stage="cognitive_mmr"
                ))
            else:
                break
                
        return final_mmr_list
