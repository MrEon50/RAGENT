import tiktoken
from typing import List

from ragent.models import ScoredDocument
from ragent.config import RagentConfig

class ContextBudgetManager:
    """Zarządza oknem tokenów i kontroluje limit do generacji modelu."""
    def __init__(self, config: RagentConfig):
        self.config = config
        try:
            self.tokenizer = tiktoken.get_encoding("cl100k_base")
        except:
            self.tokenizer = None

    def _count_tokens(self, text: str) -> int:
        if self.tokenizer:
            return len(self.tokenizer.encode(text))
        # Fallback (approximate word count * 1.3 to roughly match tokens)
        return int(len(text.split()) * 1.3)

    def assemble(self, documents: List[ScoredDocument]) -> str:
        """Kompiluje fragmenty w tekst w okienku."""
        if not documents:
            return ""

        # Ograniczanie by adaptive threshold
        if documents:
            max_score = documents[0].score # powinnien być największy z pierwszego indexu posortowanego na MMR
            threshold = max_score * self.config.adaptive_threshold_ratio
            documents = [d for d in documents if d.score >= threshold]

        # Top k Ostatnie cięcia
        documents = documents[:self.config.final_top_k]

        final_context = []
        current_tokens = 0
        max_tokens = self.config.max_context_tokens

        for i, sd in enumerate(documents):
            source_info = f"[{i+1}] Source: {sd.document.metadata.get('source_type', 'unknown')}, Date: {sd.document.metadata.get('created_at', 'unknown')}\n"
            content = f"{source_info}{sd.document.content}\n---\n"
            
            tokens_for_doc = self._count_tokens(content)
            
            if current_tokens + tokens_for_doc > max_tokens:
                # Jeśli przekraczamy budżet, nie dodajemy już więcej
                break
                
            final_context.append(content)
            current_tokens += tokens_for_doc

        return "\n".join(final_context)
