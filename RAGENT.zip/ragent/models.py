from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

@dataclass
class Document:
    """Reprezentacja pojedynczego dokumentu / fragmentu tekstu w bazie."""
    id: str
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # helper zeby szybko dostac np date utworzenia dla time decay
    @property
    def created_at(self) -> Optional[str]:
        return self.metadata.get("created_at")
        
    @property
    def source_type(self) -> str:
        return self.metadata.get("source_type", "default")

@dataclass
class ScoredDocument:
    """Dokument z nadanym score na dowolnym etapie pipeline'u."""
    document: Document
    score: float
    scoring_stage: str

@dataclass
class SearchResult:
    """Finalny wynik działania wyszukiwania RAGENT."""
    documents: List[ScoredDocument]
    pipeline_stats: Dict[str, Any] = field(default_factory=dict)
