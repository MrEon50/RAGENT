from typing import List, Dict, Any

from ragent.models import Document, ScoredDocument, SearchResult
from ragent.config import RagentConfig
from ragent.search import BM25Retriever, BaseVectorRetriever, reciprocal_rank_fusion
from ragent.reranker import CrossEncoderReranker
from ragent.cognitive import CognitiveLayer
from ragent.context import ContextBudgetManager

class AdvancedRAGPipeline:
    """Oto główny Orkiestrator RAGENT zawierający logikę Rywalizacji Wg. Informacji."""
    def __init__(
        self, 
        config: RagentConfig, 
        vector_retriever: BaseVectorRetriever, 
        embedding_model
    ):
        self.config = config
        self.vector_retriever = vector_retriever
        self.embedding_model = embedding_model
        
        # Sub-komponenty zasilające się RAGENT
        self.bm25_retriever = BM25Retriever()
        
        # Leniwa inicjalizacja na pierwszym użyciu rerank
        try:
            self.reranker = CrossEncoderReranker(model_name=config.reranker_model)
        except ImportError:
             self.reranker = None
             
        self.cognitive = CognitiveLayer(config, embedding_model=embedding_model)
        self.context_manager = ContextBudgetManager(config)

    def add_documents(self, documents: List[Document]):
        """Indeksuje na obu silnikach Hybrid Search (BM25 i Vector)"""
        # 1. BM25 (tylko trzyma tekst u siebie)
        self.bm25_retriever.index(documents)
        
        # 2. Vector Store + Embeddings
        texts = [doc.content for doc in documents]
        embeddings = self.embedding_model.encode(texts).tolist()  # Z Numpy na czystą listę
        self.vector_retriever.index(documents, embeddings)

    def search(self, query: str, metadata_filters: Dict[str, Any] = None) -> SearchResult:
        """
        Zwraca obiekt `SearchResult` z przygotowanym ostatecznie `documents` czyli konkurami.
        """
        stats = {}
        
        # 1. Metadata filtering (delegujemy do wektorowej bazy)
        # Obydwaj retrieverzy robią swój search na query a z wektorów przyjdzie ograniczony list dokumentów
        
        query_embedding = self.embedding_model.encode([query])[0].tolist()
        
        # 2a. Vector Search
        vector_kands = self.vector_retriever.search(
            query_embedding, 
            top_k=self.config.vector_top_k, 
            filters=metadata_filters
        )
        stats["vector_candidates"] = len(vector_kands)
        
        # 2b. BM25 Search
        bm25_kands = self.bm25_retriever.search(query, top_k=self.config.bm25_top_k)
        stats["bm25_candidates"] = len(bm25_kands)

        # 3. RRF (Podstawowa Walka, zderzenie z semantyką z klasycznym wyszukiwaniem po słowach)
        fusion_kands = reciprocal_rank_fusion([vector_kands, bm25_kands], k=self.config.rrf_k)
        stats["fusion_candidates"] = len(fusion_kands)
        
        # Zabezpieczenie na brak dokumentów (aby uniknąć wyjątków nizej)
        if not fusion_kands:
             return SearchResult(documents=[], pipeline_stats=stats)

        # Utnij trochę by nie wrzucać do drogiego rerankera pełnej bazy po fuzji
        # Rerank jest kosztowny zliczając go dla dużej ilości rekordów na raz
        top_fusion = fusion_kands[:self.config.reranker_top_k * 2] # bezpieczny bufor

        # 4. Reranking Cross Encoder
        if self.reranker:
             reranked_docs = self.reranker.rerank(query, top_fusion, top_k=self.config.reranker_top_k)
        else:
             print("Warning: brak Cross Encoder. Z użycia tylko RRF.")
             reranked_docs = top_fusion[:self.config.reranker_top_k]
             
        stats["reranked_candidates"] = len(reranked_docs)

        # 5. Cognitive Bias & MMR Diversity 
        biased_docs = self.cognitive.apply_cognitive_biases(query, reranked_docs)
        stats["cognitive_candidates"] = len(biased_docs)

        # Zostawmy te po biaskach, top final_top_k w kontekście się zaopiekuje 
        return SearchResult(
            documents=biased_docs,
            pipeline_stats=stats
        )

    def get_final_context(self, search_result: SearchResult) -> str:
        """Przerabia ScoredDocumenty na finalny string dla LLMA z poprawnym limiterem tokensów"""
        return self.context_manager.assemble(search_result.documents)
