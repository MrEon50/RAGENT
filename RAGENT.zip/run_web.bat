@echo off
echo.
echo ================================================
echo   RAGENT Web UI – Information Competition Chat
echo ================================================
echo.
echo Uruchamiam serwer na http://localhost:8765
echo Otworz przegladarke i wejdz na ten adres.
echo.
echo Upewnij sie ze Ollama dziala (ollama serve)
echo.

cd /d "%~dp0"

:: Zwolnij port 8765 jesli zajety przez poprzednia sesje
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8765 ^| findstr LISTENING') do (
    echo Zatrzymuje poprzedni proces na porcie 8765 [PID: %%a]...
    taskkill /PID %%a /F >nul 2>&1
)
timeout /t 1 /nobreak >nul

python -m uvicorn web.server:app --host 127.0.0.1 --port 8765

pause
